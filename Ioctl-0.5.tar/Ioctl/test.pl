
use Ioctl;

print "TCFLSH = ",TCFLSH,"\n"; 

